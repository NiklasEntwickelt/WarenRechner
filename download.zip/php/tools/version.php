    <div class="collapse" id="versionInfo">
        <div class="card card-body">
            
            <div class="list-group">
                <a class="list-group-item list-group-item-action active" aria-current="true">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1"> Changelog WR-8.2</h5>
                    </div>
                </a>
                
                
                <a class="list-group-item list-group-item-action" aria-current="true">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1 clog">
                            <i class="bi bi-square-fill" style="color:yellow"></i>
                        Recode: Tabellen Generierung</h5>
                        <small class="timeSinceDate" dateData="3/29/2022 11:02">...</small>
                    </div>
                    <p class="mb-1">Code ist nun optisch leichter lesbar</p>
                    <small></small>
                </a>
                
                
            </div>
        </div>
    </div>
    
    <script src="../js/logformatter.js"></script>