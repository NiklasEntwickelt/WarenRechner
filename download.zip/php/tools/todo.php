
    
    <div class="collapse" id="todoInfo">
        <div class="card card-body">
            
            <div class="list-group">
                <a class="list-group-item list-group-item-action active" aria-current="true">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1">TODO</h5>
                    </div>
                </a>
                




                <a class="list-group-item list-group-item-action" aria-current="true">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1 clog"><i class="bi bi-square-fill" style="color:green"></i>
                        Gerade sind keine Features geplant</h5>
                        <small class="timeSinceDate" dateData="3/29/2022 10:47">...</small>
                    </div>
                    <p class="mb-1"></p>
                    <small></small>
                </a>
                
            </div>
        </div>
    </div>
    
